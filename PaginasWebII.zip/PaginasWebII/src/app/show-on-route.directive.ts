import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Directive({
  selector: '[appShowOnRoute]'
})
export class ShowOnRouteDirective {
  private hasView = false;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  @Input() set appShowOnRoute(path: string) {
    const currentPath = this.router.url;
    const shouldShow = currentPath.includes(path);

    if (shouldShow && !this.hasView) {
      this.viewContainer.createEmbeddedView(this.templateRef);
      this.hasView = true;
    } else if (!shouldShow && this.hasView) {
      this.viewContainer.clear();
      this.hasView = false;
    }
  }
}