import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  session!: boolean;
  today = new Date(); // ← Agregar esta línea

  constructor(private auth: AuthService, private router: Router) {
    this.auth.isAuthenticated().subscribe(session => this.session = session);
  }

  Logout() {
    this.auth.logout();
    this.router.navigateByUrl('/login');
  }
}