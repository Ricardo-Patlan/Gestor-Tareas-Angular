// src/app/services/task.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface Task {
  id: number;
  title: string;
  completed: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private readonly STORAGE_KEY = 'tasks';
  private taskSubject = new BehaviorSubject<Task[]>([]);
  private currentId = 1;

  constructor() {
    this.loadTasksFromStorage();
  }

  // Función para cargar tareas desde localStorage
  private loadTasksFromStorage(): void {
    const storedTasks = localStorage.getItem(this.STORAGE_KEY);
    if (storedTasks) {
      const tasks: Task[] = JSON.parse(storedTasks);
      this.taskSubject.next(tasks);
      this.updateCurrentId(tasks);
    } else {
      // Si no hay tareas guardadas, cargar tareas de muestra
      this.loadSampleTasks();
    }
  }

  // Función para cargar tareas de muestra
  private loadSampleTasks(): void {
    const sampleTasks: Task[] = [
      { id: 1, title: 'Comprar leche', completed: false },
      { id: 2, title: 'Hacer ejercicio', completed: true },
      { id: 3, title: 'Estudiar Angular', completed: false },
      { id: 4, title: 'Llamar al dentista', completed: false },
      { id: 5, title: 'Limpiar la casa', completed: true }
    ];
    
    this.taskSubject.next(sampleTasks);
    this.updateCurrentId(sampleTasks);
    this.saveTasksToStorage(); // Guardar las tareas de muestra
  }

  // Función para guardar tareas en localStorage
  private saveTasksToStorage(): void {
    const tasks = this.taskSubject.getValue();
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(tasks));
  }

  // Función para determinar el próximo ID disponible
  private updateCurrentId(tasks: Task[]): void {
    if (tasks.length > 0) {
      const maxId = Math.max(...tasks.map(task => task.id));
      this.currentId = maxId + 1;
    }
  }

  // Tu función original getTask()
  getTask(): Observable<Task[]> {
    return this.taskSubject.asObservable();
  }

  // Tu función original addTask() con localStorage
  addTask(title: string): void {
    const newTask: Task = {
      id: this.currentId++,
      title,
      completed: false
    };
    const updatedTasks = [...this.taskSubject.getValue(), newTask];
    this.taskSubject.next(updatedTasks);
    this.saveTasksToStorage(); // Solo agrego esta línea
  }

  // Nueva función para completar tareas
  toggleTaskCompletion(id: number): void {
    const currentTasks = this.taskSubject.getValue();
    const updatedTasks = currentTasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    );
    this.taskSubject.next(updatedTasks);
    this.saveTasksToStorage();
  }
}