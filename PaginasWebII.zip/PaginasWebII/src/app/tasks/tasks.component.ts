// src/app/tasks/tasks.component.ts
import { Component } from '@angular/core';

export interface Task {
  id: number;
  title: string;
  completed: boolean;
}

@Component({
  selector: 'app-tasks',
  standalone: false,
  template: `
    <section class="container py-4">
      <div>
        <h1 style="text-align: center; 
                   color: #333; 
                   margin: 0 0 40px 0; 
                   font-weight: 300;
                   font-size: 2.5rem;
                   font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
          Gestión de Tareas
        </h1>
        
        <!-- Agregar el formulario aquí -->
        
        <!-- Lista de tareas -->
        <app-list></app-list>
      </div>
      <router-outlet></router-outlet>
    </section>
  `,
  styles: ``
})
export class TasksComponent {
  
}