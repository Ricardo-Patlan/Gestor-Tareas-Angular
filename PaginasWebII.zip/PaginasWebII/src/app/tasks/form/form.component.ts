// src/app/tasks/form/form.component.ts
import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { TaskService } from '../../services/task.service';

@Component({
  selector: 'app-form',
  standalone: false,
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss'],
})
export class FormComponent {
  // Formulario reactivo
  taskForm: FormGroup;

  constructor(private taskService: TaskService) {
    // Inicializar el formulario reactivo
    this.taskForm = new FormGroup({
      title: new FormControl('', [
        Validators.required,
        Validators.minLength(1),
      ]),
    });
  }

  // Getter para facilitar el acceso al control en la plantilla
  get title() {
    return this.taskForm.get('title');
  }

  agregarTarea(): void {
    // Verificar si el formulario es válido
    if (this.taskForm.valid) {
      const titulo = this.taskForm.value.title.trim();

      if (titulo) {
        console.log('Agregando tarea:', titulo);
        this.taskService.addTask(titulo);

        // Limpiar el formulario automáticamente
        this.taskForm.reset();
      }
    }
  }

  // Método opcional para verificar si el formulario tiene errores
  hasError(controlName: string, errorType: string): boolean {
    const control = this.taskForm.get(controlName);
    return control ? control.hasError(errorType) && control.touched : false;
  }
}
