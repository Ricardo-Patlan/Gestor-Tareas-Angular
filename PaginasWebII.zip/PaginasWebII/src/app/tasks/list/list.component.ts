import { Component } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html'
  // Eliminamos styleUrl/stylesheet si no se usa
})
export class ListComponent {
  // Tu código del componente
}