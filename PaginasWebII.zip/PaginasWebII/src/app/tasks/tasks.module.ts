// src/app/tasks/tasks.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { TasksRoutingModule } from './tasks-routing.module';
import { TasksComponent } from './tasks.component';
import { ListComponent } from './list/list.component';
import { FormComponent } from './form/form.component';

@NgModule({
  declarations: [TasksComponent, ListComponent, FormComponent],
  imports: [
    CommonModule,
    FormsModule, // Para ngModel
    ReactiveFormsModule, // Para formularios reactivos
    RouterModule, // Para routing
    TasksRoutingModule, // Rutas específicas del módulo
  ],
})
export class TasksModule {}
