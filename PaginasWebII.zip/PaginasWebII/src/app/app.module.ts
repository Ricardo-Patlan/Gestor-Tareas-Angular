import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { CapitalizePipe } from './pipes/capitalize.pipe';
import { AlternateCasePipe } from './pipes/alternate-case.pipe';
import { ShowOnRouteDirective } from './show-on-route.directive';


@NgModule({
  declarations: [AppComponent, HeaderComponent, LoginComponent, CapitalizePipe,  AlternateCasePipe,     ShowOnRouteDirective],
  imports: [BrowserModule, AppRoutingModule, ReactiveFormsModule, FormsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
